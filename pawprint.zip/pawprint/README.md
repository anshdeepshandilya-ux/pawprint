# Pawprint – pet services discovery, comparison and referral marketplace

Node 18+ · Express · SQLite (better-sqlite3). Single process, no build step.

## Run
    npm install
    ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='a-long-password' npm run seed && npm start
(If ADMIN_PASSWORD is not set, a random admin password is printed once on first start.)
Open http://localhost:3000. Run `npm test` for the 39-check integration suite.

Environment: PORT, BASE_URL (used in sitemap/canonical), JWT_SECRET (else generated into data/.secret), DB_PATH.

## What is built
Cities (add more from the admin API), 7 categories, search + filters (service, pet, price, rating, open now, home, emergency, distance when coordinates exist),
5 sort options, compare up to 4, provider pages with JSON-LD, `/go/:id` referral redirect with click tracking, accounts (JWT, bcrypt), pets,
favourites, recently visited, saved comparisons, reviews (one per user, link-spam held for moderation, always "unverified" unless an admin marks verified),
business registration queue, admin dashboard (approve/reject, edit booking URLs, verify, hide/delete, moderate reviews, users/roles, click stats), sitemap, robots.txt.

## Data
`data/providers.json` holds 65 real businesses compiled from public web pages (names, localities, addresses and websites only; source URL stored per row).
No ratings, prices, hours or reviews were copied from third parties. Every row is "Unverified" until an admin ticks Verified.
Load more with `node seed.js your-file.json` (same shape; existing slugs are skipped).

## Not included yet (needs credentials or decisions)
Google OAuth, SMS/email OTP, photo uploads (needs object storage), Google Maps embed/geocoding (needs an API key, so lat/lng are empty and "nearest" only
works once you add coordinates), website analytics, verified-customer review proof, multi-instance rate-limit store.
Before going live: serve over HTTPS, set JWT_SECRET and BASE_URL, back up data/pawprint.db, and move the token from localStorage to an httpOnly cookie plus CSRF protection if you add third-party scripts.
