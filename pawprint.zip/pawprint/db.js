const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'data', 'pawprint.db'));
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user' CHECK(role IN('user','admin')), created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS cities(slug TEXT PRIMARY KEY, name TEXT NOT NULL, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS categories(slug TEXT PRIMARY KEY, name TEXT NOT NULL, sort INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS providers(id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  category TEXT NOT NULL REFERENCES categories(slug), city TEXT NOT NULL REFERENCES cities(slug), locality TEXT, address TEXT,
  phone TEXT, email TEXT, website TEXT, booking_url TEXT, description TEXT, services TEXT DEFAULT '[]', pets TEXT DEFAULT '["Dog","Cat"]',
  starting_price INTEGER, hours_text TEXT, open_min INTEGER, close_min INTEGER, is24 INTEGER DEFAULT 0,
  home_service INTEGER DEFAULT 0, emergency INTEGER DEFAULT 0, lat REAL, lng REAL,
  verified INTEGER DEFAULT 0, maps_url TEXT, source TEXT DEFAULT 'submission', source_url TEXT,
  status TEXT DEFAULT 'active' CHECK(status IN('active','hidden')), created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS ix_prov ON providers(city, category, status);
CREATE TABLE IF NOT EXISTS submissions(id INTEGER PRIMARY KEY, data TEXT NOT NULL, status TEXT DEFAULT 'pending'
  CHECK(status IN('pending','approved','rejected')), created_at TEXT DEFAULT CURRENT_TIMESTAMP, reviewed_by INTEGER);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, provider_id INTEGER NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, stars INTEGER NOT NULL CHECK(stars BETWEEN 1 AND 5), text TEXT NOT NULL,
  verified INTEGER DEFAULT 0, status TEXT DEFAULT 'published' CHECK(status IN('published','pending','removed')),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(provider_id,user_id));
CREATE TABLE IF NOT EXISTS pets(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, type TEXT NOT NULL, breed TEXT, age REAL, gender TEXT, preferences TEXT);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_id INTEGER NOT NULL REFERENCES providers(id) ON DELETE CASCADE, PRIMARY KEY(user_id,provider_id));
CREATE TABLE IF NOT EXISTS recent(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_id INTEGER NOT NULL REFERENCES providers(id) ON DELETE CASCADE, at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,provider_id));
CREATE TABLE IF NOT EXISTS comparisons(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, provider_ids TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS clicks(id INTEGER PRIMARY KEY, provider_id INTEGER NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  user_id INTEGER, outcome TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const CITIES=[['mumbai','Mumbai'],['bengaluru','Bengaluru'],['delhi','Delhi'],['gurugram','Gurugram'],['noida','Noida']];
const CATS=[['groom','Grooming & salons'],['vet','Veterinary'],['board','Boarding & daycare'],['train','Training'],['sit','Walking & sitting'],['shop','Products & shopping'],['other','Other pet services']];
const ic=db.prepare('INSERT OR IGNORE INTO cities(slug,name) VALUES(?,?)'), cc=db.prepare('INSERT OR IGNORE INTO categories(slug,name,sort) VALUES(?,?,?)');
CITIES.forEach(c=>ic.run(...c)); CATS.forEach((c,i)=>cc.run(c[0],c[1],i));
if(!db.prepare("PRAGMA table_info(providers)").all().some(c=>c.name==='maps_url'))db.exec('ALTER TABLE providers ADD COLUMN maps_url TEXT');
module.exports = db;
