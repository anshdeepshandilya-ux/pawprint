// Usage: node seed.js [file.json]. Loads providers; existing slugs are skipped. Nothing is verified until an admin verifies it.
const db=require('./db'),fs=require('fs');
const slug=s=>s.toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
function load(file){const rows=JSON.parse(fs.readFileSync(file,'utf8'));
const ins=db.prepare(`INSERT INTO providers(slug,name,category,city,locality,address,phone,email,website,booking_url,description,services,pets,starting_price,hours_text,open_min,close_min,is24,home_service,emergency,maps_url,source,source_url)
VALUES(@slug,@name,@category,@city,@locality,@address,@phone,@email,@website,@booking_url,@description,@services,@pets,@starting_price,@hours_text,@open_min,@close_min,@is24,@home_service,@emergency,@maps_url,@source,@source_url)
ON CONFLICT(slug) DO UPDATE SET phone=COALESCE(providers.phone,excluded.phone),website=COALESCE(providers.website,excluded.website),address=COALESCE(providers.address,excluded.address),locality=COALESCE(providers.locality,excluded.locality),maps_url=COALESCE(providers.maps_url,excluded.maps_url),hours_text=COALESCE(providers.hours_text,excluded.hours_text),open_min=COALESCE(providers.open_min,excluded.open_min),close_min=COALESCE(providers.close_min,excluded.close_min),is24=MAX(providers.is24,excluded.is24)`);
let n=0;db.transaction(()=>{for(const r of rows){const s=slug(r.name+'-'+r.city);
ins.run({slug:s,name:r.name,category:r.category,city:r.city,locality:r.locality||null,address:r.address||null,phone:r.phone||null,email:r.email||null,website:r.website||null,booking_url:r.booking_url||null,description:r.description||null,services:JSON.stringify(r.services||[]),pets:JSON.stringify(r.pets||['Dog','Cat']),starting_price:r.starting_price??null,hours_text:r.hours_text||null,open_min:r.open_min??null,close_min:r.close_min??null,is24:r.is24?1:0,maps_url:r.maps_url||('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent([r.name,r.address,r.locality,r.city].filter(Boolean).join(' '))),home_service:r.home_service?1:0,emergency:r.emergency?1:0,source:'public-web',source_url:r.source_url||null});n++}})();
return n}
if(require.main===module)console.log('inserted',load(process.argv[2]||'data/providers.json'),'providers');
module.exports={load,slug};
