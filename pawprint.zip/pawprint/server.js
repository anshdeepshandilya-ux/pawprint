const express=require('express'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const fs=require('fs'),path=require('path'),crypto=require('crypto'),db=require('./db'),{slug}=require('./seed');
const PORT=process.env.PORT||3000, BASE=process.env.BASE_URL||`http://localhost:${PORT}`;
// JWT secret: env var, else a persisted random secret.
const sf=path.join(__dirname,'data','.secret');
const SECRET=process.env.JWT_SECRET||(fs.existsSync(sf)?fs.readFileSync(sf,'utf8'):(()=>{const s=crypto.randomBytes(32).toString('hex');fs.writeFileSync(sf,s,{mode:0o600});return s})());
// Admin bootstrap: only when no admin exists.
if(!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()){
  const email=(process.env.ADMIN_EMAIL||'admin@pawprint.local').toLowerCase(),pw=process.env.ADMIN_PASSWORD||crypto.randomBytes(9).toString('base64url');
  db.prepare("INSERT INTO users(name,email,pass_hash,role) VALUES('Admin',?,?, 'admin')").run(email,bcrypt.hashSync(pw,12));
  console.log(`\nAdmin created: ${email} / ${process.env.ADMIN_PASSWORD?'(from ADMIN_PASSWORD)':pw}\n`);}
const app=express();app.set('trust proxy',1);
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'",'https://fonts.googleapis.com'],fontSrc:['https://fonts.gstatic.com'],imgSrc:["'self'",'data:'],connectSrc:["'self'"],objectSrc:["'none'"],frameAncestors:["'none'"]}}}));
app.use(express.json({limit:'50kb'}));
const lim=(n,m)=>rateLimit({windowMs:m*60000,limit:n,standardHeaders:true,legacyHeaders:false});
app.use('/api',lim(300,15));
const J=(s,d=[])=>{try{return JSON.parse(s)}catch{return d}};
const fail=(res,c,m)=>res.status(c).json({error:m});
const str=(v,max,min=0)=>typeof v==='string'&&v.trim().length>=min&&v.trim().length<=max?v.trim():null;
const emailOk=e=>typeof e==='string'&&e.length<=120&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const urlOk=u=>{try{const x=new URL(u);return['http:','https:'].includes(x.protocol)}catch{return false}};
const auth=(req,res,next)=>{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return fail(res,401,'Login required');
 try{const p=jwt.verify(h.slice(7),SECRET);const u=db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(p.id);if(!u)throw 0;req.user=u;next()}catch{fail(res,401,'Session expired. Please log in again.')}};
const optAuth=(req,res,next)=>{const h=req.headers.authorization||'';if(h.startsWith('Bearer ')){try{req.user=db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(jwt.verify(h.slice(7),SECRET).id)}catch{}}next()};
const admin=(req,res,next)=>req.user?.role==='admin'?next():fail(res,403,'Admin access required');
const token=u=>jwt.sign({id:u.id},SECRET,{expiresIn:'7d'});
const wrap=fn=>(req,res,next)=>{try{fn(req,res,next)}catch(e){console.error(e);fail(res,500,'Something went wrong')}};

// ---- public data ----
const SEL=`SELECT p.*,(SELECT ROUND(AVG(stars),1) FROM reviews r WHERE r.provider_id=p.id AND r.status='published') rating,
(SELECT COUNT(*) FROM reviews r WHERE r.provider_id=p.id AND r.status='published') review_count FROM providers p`;
const shape=(p,pos)=>{if(!p)return p;const o={...p,services:J(p.services),pets:J(p.pets),booking_url:undefined,has_booking_link:!!(p.booking_url||p.website),verified:!!p.verified,home_service:!!p.home_service,emergency:!!p.emergency,is24:!!p.is24,unverified_source:p.source!=='submission'&&!p.verified};
 if(pos&&p.lat!=null&&p.lng!=null){const R=6371,d=x=>x*Math.PI/180,a=Math.sin(d(p.lat-pos.lat)/2)**2+Math.cos(d(pos.lat))*Math.cos(d(p.lat))*Math.sin(d(p.lng-pos.lng)/2)**2;o.distance_km=+(2*R*Math.asin(Math.sqrt(a))).toFixed(1)}
 delete o.booking_url;delete o.email;return o};
const nowMin=()=>{const t=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'}));return t.getHours()*60+t.getMinutes()};
app.get('/api/meta',(q,res)=>res.json({cities:db.prepare('SELECT slug,name FROM cities WHERE active=1').all(),categories:db.prepare('SELECT slug,name FROM categories ORDER BY sort').all()}));
app.get('/api/providers',wrap((req,res)=>{const q=req.query,w=["p.status='active'"],a=[];
 if(q.city){w.push('p.city=?');a.push(String(q.city))}if(q.category){w.push('p.category=?');a.push(String(q.category))}
 if(q.locality){w.push('p.locality LIKE ?');a.push('%'+String(q.locality).slice(0,40)+'%')}
 if(q.q){const t='%'+String(q.q).slice(0,60).toLowerCase()+'%';w.push("(LOWER(p.name) LIKE ? OR LOWER(p.services) LIKE ? OR LOWER(IFNULL(p.locality,'')) LIKE ?)");a.push(t,t,t)}
 if(q.service){w.push('p.services LIKE ?');a.push('%"'+String(q.service).replace(/["%_\\]/g,'')+'"%')}
 if(q.pet){w.push('p.pets LIKE ?');a.push('%"'+String(q.pet).replace(/["%_\\]/g,'')+'"%')}
 if(q.maxPrice){w.push('p.starting_price<=?');a.push(+q.maxPrice||0)}
 if(q.home==='1')w.push('p.home_service=1');if(q.emergency==='1')w.push('p.emergency=1');
 if(q.open==='1'){w.push('(p.is24=1 OR (p.open_min IS NOT NULL AND ?>=p.open_min AND ?<p.close_min))');a.push(nowMin(),nowMin())}
 let rows=db.prepare(SEL+' WHERE '+w.join(' AND ')).all(...a);
 if(q.minRating)rows=rows.filter(r=>(r.rating||0)>=+q.minRating);
 const pos=q.lat&&q.lng?{lat:+q.lat,lng:+q.lng}:null;let out=rows.map(r=>shape(r,pos));
 const by={rating:(x,y)=>(y.rating||0)-(x.rating||0),price_asc:(x,y)=>(x.starting_price??1e9)-(y.starting_price??1e9),price_desc:(x,y)=>(y.starting_price??-1)-(x.starting_price??-1),
  nearest:(x,y)=>(x.distance_km??1e9)-(y.distance_km??1e9),recommended:(x,y)=>(y.verified-x.verified)||(y.review_count-x.review_count)||x.name.localeCompare(y.name)};
 out.sort(by[q.sort]||by.recommended);const total=out.length,off=Math.max(0,+q.offset||0),lim=Math.min(50,+q.limit||24);
 res.json({total,items:out.slice(off,off+lim)})}));
app.get('/api/providers/:slug',optAuth,wrap((req,res)=>{const p=db.prepare(SEL+" WHERE p.slug=? AND p.status='active'").get(req.params.slug);if(!p)return fail(res,404,'Provider not found');
 if(req.user)db.prepare('INSERT INTO recent(user_id,provider_id) VALUES(?,?) ON CONFLICT(user_id,provider_id) DO UPDATE SET at=CURRENT_TIMESTAMP').run(req.user.id,p.id);
 const o=shape(p);o.phone=p.phone;res.json(o)}));
app.get('/api/providers/:id/reviews',wrap((req,res)=>{const o=req.query.sort==='top'?'r.stars DESC,r.created_at DESC':'r.created_at DESC';
 res.json(db.prepare(`SELECT r.id,r.stars,r.text,r.verified,r.created_at,u.name author FROM reviews r JOIN users u ON u.id=r.user_id WHERE r.provider_id=? AND r.status='published' ORDER BY ${o} LIMIT 100`).all(req.params.id))}));
// Referral: logs the click, then redirects to the provider's own booking page (or website). Never claims a booking.
app.get('/go/:id',optAuth,wrap((req,res)=>{const p=db.prepare("SELECT id,booking_url,website FROM providers WHERE id=? AND status='active'").get(req.params.id);if(!p)return res.redirect('/');
 const url=[p.booking_url,p.website].find(u=>u&&urlOk(u));db.prepare('INSERT INTO clicks(provider_id,user_id,outcome) VALUES(?,?,?)').run(p.id,req.user?.id||null,url?'redirect':'contact');
 res.redirect(url||`/?contact=${p.id}`)}));
app.get('/api/providers/:id/contact',wrap((req,res)=>{const p=db.prepare("SELECT name,phone,address,maps_url FROM providers WHERE id=? AND status='active'").get(req.params.id);p?res.json(p):fail(res,404,'Not found')}));

// ---- auth ----
const al=lim(20,15);
app.post('/api/auth/register',al,wrap((req,res)=>{const name=str(req.body.name,60,2),email=String(req.body.email||'').toLowerCase().trim(),pw=req.body.password;
 if(!name||!emailOk(email)||typeof pw!=='string'||pw.length<8||pw.length>100)return fail(res,400,'Enter a name, a valid email and a password of at least 8 characters.');
 if(db.prepare('SELECT 1 FROM users WHERE email=?').get(email))return fail(res,409,'An account with this email already exists.');
 const id=db.prepare('INSERT INTO users(name,email,pass_hash) VALUES(?,?,?)').run(name,email,bcrypt.hashSync(pw,12)).lastInsertRowid;
 const u={id,name,email,role:'user'};res.status(201).json({token:token(u),user:u})}));
app.post('/api/auth/login',al,wrap((req,res)=>{const email=String(req.body.email||'').toLowerCase().trim(),u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
 if(!u||!bcrypt.compareSync(String(req.body.password||''),u.pass_hash))return fail(res,401,'Incorrect email or password.');
 res.json({token:token(u),user:{id:u.id,name:u.name,email:u.email,role:u.role}})}));
app.get('/api/me',auth,(req,res)=>res.json(req.user));
app.put('/api/me',auth,wrap((req,res)=>{const n=str(req.body.name,60,2);if(!n)return fail(res,400,'Name must be 2–60 characters.');db.prepare('UPDATE users SET name=? WHERE id=?').run(n,req.user.id);res.json({...req.user,name:n})}));

// ---- pets, favourites, recent, comparisons ----
app.get('/api/pets',auth,(req,res)=>res.json(db.prepare('SELECT * FROM pets WHERE user_id=?').all(req.user.id)));
app.post('/api/pets',auth,wrap((req,res)=>{const b=req.body,name=str(b.name,40,1),type=['Dog','Cat','Other'].includes(b.type)?b.type:null,age=b.age===''||b.age==null?null:+b.age;
 if(!name||!type||(age!=null&&!(age>=0&&age<=40)))return fail(res,400,'Pet name, type (Dog, Cat or Other) and a sensible age are required.');
 const id=db.prepare('INSERT INTO pets(user_id,name,type,breed,age,gender,preferences) VALUES(?,?,?,?,?,?,?)').run(req.user.id,name,type,str(b.breed,60),age,['Male','Female'].includes(b.gender)?b.gender:null,str(b.preferences,300)).lastInsertRowid;
 res.status(201).json(db.prepare('SELECT * FROM pets WHERE id=?').get(id))}));
app.delete('/api/pets/:id',auth,(req,res)=>{db.prepare('DELETE FROM pets WHERE id=? AND user_id=?').run(req.params.id,req.user.id);res.json({ok:true})});
app.get('/api/favorites',auth,(req,res)=>res.json(db.prepare(SEL+' JOIN favorites f ON f.provider_id=p.id WHERE f.user_id=?').all(req.user.id).map(r=>shape(r))));
app.put('/api/favorites/:id',auth,wrap((req,res)=>{if(!db.prepare('SELECT 1 FROM providers WHERE id=?').get(req.params.id))return fail(res,404,'Not found');db.prepare('INSERT OR IGNORE INTO favorites VALUES(?,?)').run(req.user.id,req.params.id);res.json({ok:true})}));
app.delete('/api/favorites/:id',auth,(req,res)=>{db.prepare('DELETE FROM favorites WHERE user_id=? AND provider_id=?').run(req.user.id,req.params.id);res.json({ok:true})});
app.get('/api/recent',auth,(req,res)=>res.json(db.prepare(SEL+' JOIN recent x ON x.provider_id=p.id WHERE x.user_id=? ORDER BY x.at DESC LIMIT 8').all(req.user.id).map(r=>shape(r))));
app.get('/api/comparisons',auth,(req,res)=>res.json(db.prepare('SELECT * FROM comparisons WHERE user_id=? ORDER BY id DESC').all(req.user.id).map(c=>({...c,provider_ids:J(c.provider_ids)}))));
app.post('/api/comparisons',auth,wrap((req,res)=>{const ids=Array.isArray(req.body.provider_ids)?[...new Set(req.body.provider_ids.map(Number))].filter(Number.isInteger):[],n=str(req.body.name,60,1);
 if(!n||ids.length<2||ids.length>4)return fail(res,400,'Give the list a name and choose 2–4 providers.');
 res.status(201).json({id:db.prepare('INSERT INTO comparisons(user_id,name,provider_ids) VALUES(?,?,?)').run(req.user.id,n,JSON.stringify(ids)).lastInsertRowid})}));
app.get('/api/compare',wrap((req,res)=>{const ids=String(req.query.ids||'').split(',').map(Number).filter(Number.isInteger).slice(0,4);if(ids.length<2)return fail(res,400,'Choose 2–4 providers.');
 res.json(ids.map(id=>db.prepare(SEL+" WHERE p.id=? AND p.status='active'").get(id)).filter(Boolean).map(r=>shape(r)))}));

// ---- reviews ----
const SPAM=/https?:\/\/|www\.|\.com\b|whatsapp|telegram|(.)\1{6,}/i;
app.post('/api/providers/:id/reviews',auth,lim(10,60),wrap((req,res)=>{const stars=+req.body.stars,text=str(req.body.text,800,15);
 if(!(stars>=1&&stars<=5&&Number.isInteger(stars))||!text)return fail(res,400,'Give a 1–5 rating and a review of at least 15 characters.');
 if(!db.prepare("SELECT 1 FROM providers WHERE id=? AND status='active'").get(req.params.id))return fail(res,404,'Provider not found');
 if(db.prepare('SELECT 1 FROM reviews WHERE provider_id=? AND user_id=?').get(req.params.id,req.user.id))return fail(res,409,'You have already reviewed this provider.');
 const status=SPAM.test(text)?'pending':'published'; // suspected spam waits for moderation
 db.prepare('INSERT INTO reviews(provider_id,user_id,stars,text,status) VALUES(?,?,?,?,?)').run(req.params.id,req.user.id,stars,text,status);
 res.status(201).json({status,message:status==='pending'?'Thanks. Your review will appear once a moderator approves it.':'Review posted.'})}));

// ---- business registration ----
app.post('/api/submissions',lim(5,60),wrap((req,res)=>{const b=req.body,d={name:str(b.name,100,2),category:b.category,city:b.city,locality:str(b.locality,80,2),address:str(b.address,250,5),phone:str(b.phone,20,8),email:b.email,website:b.website||null,booking_url:b.booking_url||null,
 services:Array.isArray(b.services)?b.services.map(s=>str(s,60,1)).filter(Boolean).slice(0,30):[],starting_price:b.starting_price===''||b.starting_price==null?null:+b.starting_price,hours_text:str(b.hours_text,100),description:str(b.description,1000),credentials:str(b.credentials,300)};
 const okCat=db.prepare('SELECT 1 FROM categories WHERE slug=?').get(d.category),okCity=db.prepare('SELECT 1 FROM cities WHERE slug=?').get(d.city);
 if(!d.name||!d.locality||!d.address||!d.phone||!/^[+\d][\d\s-]{7,}$/.test(d.phone)||!emailOk(d.email)||!okCat||!okCity)return fail(res,400,'Check the required fields: name, category, city, locality, address, phone and a valid email.');
 for(const k of['website','booking_url'])if(d[k]&&!urlOk(d[k]))return fail(res,400,`${k==='website'?'Website':'Booking URL'} must start with http:// or https://`);
 if(d.starting_price!=null&&!(d.starting_price>=0&&d.starting_price<=1000000))return fail(res,400,'Starting price is not valid.');
 db.prepare('INSERT INTO submissions(data) VALUES(?)').run(JSON.stringify(d));res.status(201).json({message:'Submitted. Your listing goes live after admin review.'})}));

// ---- admin ----
const A=express.Router();A.use(auth,admin);app.use('/api/admin',A);
A.get('/stats',(q,res)=>res.json({providers:db.prepare('SELECT COUNT(*) n FROM providers').get().n,users:db.prepare('SELECT COUNT(*) n FROM users').get().n,pendingSubmissions:db.prepare("SELECT COUNT(*) n FROM submissions WHERE status='pending'").get().n,pendingReviews:db.prepare("SELECT COUNT(*) n FROM reviews WHERE status='pending'").get().n,clicks:db.prepare('SELECT COUNT(*) n FROM clicks').get().n}));
A.get('/submissions',(q,res)=>res.json(db.prepare("SELECT * FROM submissions WHERE status='pending' ORDER BY id").all().map(s=>({...s,data:J(s.data,{})}))));
A.post('/submissions/:id/approve',wrap((req,res)=>{const s=db.prepare("SELECT * FROM submissions WHERE id=? AND status='pending'").get(req.params.id);if(!s)return fail(res,404,'Not found');const d=J(s.data,{});
 let sl=slug(d.name+'-'+d.city),i=1;while(db.prepare('SELECT 1 FROM providers WHERE slug=?').get(sl))sl=slug(d.name+'-'+d.city)+'-'+(++i);
 db.transaction(()=>{db.prepare(`INSERT INTO providers(slug,name,category,city,locality,address,phone,email,website,booking_url,description,services,starting_price,hours_text,source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'submission')`).run(sl,d.name,d.category,d.city,d.locality,d.address,d.phone,d.email,d.website,d.booking_url,d.description,JSON.stringify(d.services),d.starting_price,d.hours_text);
  db.prepare("UPDATE submissions SET status='approved',reviewed_by=? WHERE id=?").run(req.user.id,s.id)})();res.json({slug:sl})}));
A.post('/submissions/:id/reject',(req,res)=>{db.prepare("UPDATE submissions SET status='rejected',reviewed_by=? WHERE id=?").run(req.user.id,req.params.id);res.json({ok:true})});
A.get('/providers',(q,res)=>res.json(db.prepare(`SELECT p.*,(SELECT COUNT(*) FROM clicks c WHERE c.provider_id=p.id) clicks FROM providers p ORDER BY p.city,p.name`).all().map(p=>({...p,services:J(p.services)}))));
A.put('/providers/:id',wrap((req,res)=>{const p=db.prepare('SELECT * FROM providers WHERE id=?').get(req.params.id);if(!p)return fail(res,404,'Not found');const b=req.body,n={...p};
 for(const k of['name','locality','address','phone','email','description','hours_text'])if(k in b)n[k]=str(b[k],500)||null;
 for(const k of['website','booking_url'])if(k in b){if(b[k]&&!urlOk(b[k]))return fail(res,400,'URL must start with http:// or https://');n[k]=b[k]||null}
 for(const k of['verified','home_service','emergency','is24'])if(k in b)n[k]=b[k]?1:0;
 if('status' in b&&['active','hidden'].includes(b.status))n.status=b.status;
 if('starting_price' in b)n.starting_price=b.starting_price===''||b.starting_price==null?null:+b.starting_price;
 if(Array.isArray(b.services))n.services=JSON.stringify(b.services.map(s=>str(s,60,1)).filter(Boolean));
 for(const k of['lat','lng'])if(k in b)n[k]=b[k]===''||b[k]==null?null:+b[k];
 db.prepare(`UPDATE providers SET name=@name,locality=@locality,address=@address,phone=@phone,email=@email,description=@description,hours_text=@hours_text,website=@website,booking_url=@booking_url,verified=@verified,home_service=@home_service,emergency=@emergency,is24=@is24,status=@status,starting_price=@starting_price,services=@services,lat=@lat,lng=@lng WHERE id=@id`).run(n);res.json({ok:true})}));
A.delete('/providers/:id',(req,res)=>{db.prepare('DELETE FROM providers WHERE id=?').run(req.params.id);res.json({ok:true})});
A.get('/reviews',(q,res)=>res.json(db.prepare("SELECT r.*,u.name author,p.name provider FROM reviews r JOIN users u ON u.id=r.user_id JOIN providers p ON p.id=r.provider_id WHERE r.status!='removed' ORDER BY (r.status='pending') DESC,r.created_at DESC LIMIT 200").all()));
A.put('/reviews/:id',(req,res)=>{const s=['published','pending','removed'].includes(req.body.status)?req.body.status:null;if(!s)return fail(res,400,'Bad status');db.prepare('UPDATE reviews SET status=?,verified=? WHERE id=?').run(s,req.body.verified?1:0,req.params.id);res.json({ok:true})});
A.get('/users',(q,res)=>res.json(db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id').all()));
A.put('/users/:id/role',(req,res)=>{if(+req.params.id===req.user.id)return fail(res,400,'You cannot change your own role.');if(!['user','admin'].includes(req.body.role))return fail(res,400,'Bad role');db.prepare('UPDATE users SET role=? WHERE id=?').run(req.body.role,req.params.id);res.json({ok:true})});
A.get('/clicks',(q,res)=>res.json(db.prepare("SELECT p.name,p.city,COUNT(c.id) clicks,SUM(c.outcome='redirect') redirects FROM clicks c JOIN providers p ON p.id=c.provider_id GROUP BY p.id ORDER BY clicks DESC LIMIT 50").all()));
A.get('/cities',(q,res)=>res.json(db.prepare('SELECT * FROM cities').all()));
A.post('/cities',wrap((req,res)=>{const n=str(req.body.name,50,2);if(!n)return fail(res,400,'City name required');db.prepare('INSERT OR IGNORE INTO cities(slug,name) VALUES(?,?)').run(slug(n),n);res.status(201).json({ok:true})}));
A.post('/categories',wrap((req,res)=>{const n=str(req.body.name,50,2);if(!n)return fail(res,400,'Category name required');db.prepare('INSERT OR IGNORE INTO categories(slug,name,sort) VALUES(?,?,99)').run(slug(n),n);res.status(201).json({ok:true})}));

// ---- SEO + static ----
const pub=path.join(__dirname,'public'),tpl=()=>fs.readFileSync(path.join(pub,'index.html'),'utf8');
const E=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
app.get('/robots.txt',(q,res)=>res.type('text').send(`User-agent: *\nDisallow: /api/\nDisallow: /go/\nSitemap: ${BASE}/sitemap.xml\n`));
app.get('/sitemap.xml',(q,res)=>res.type('xml').send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${BASE}/</loc></url>${db.prepare("SELECT slug FROM providers WHERE status='active'").all().map(p=>`<url><loc>${BASE}/p/${p.slug}</loc></url>`).join('')}</urlset>`));
app.get('/p/:slug',wrap((req,res)=>{const p=db.prepare("SELECT * FROM providers WHERE slug=? AND status='active'").get(req.params.slug);if(!p)return res.status(404).send(tpl());
 const ld={'@context':'https://schema.org','@type':'LocalBusiness',name:p.name,address:[p.address,p.locality,p.city].filter(Boolean).join(', '),...(p.website?{url:p.website}:{})};
 const d=`${p.name} in ${p.locality||p.city}. Compare services and go to the provider’s own booking page.`;
 res.send(tpl().replace(/<title>.*?<\/title>/,`<title>${E(p.name)} – Pawprint</title>`).replace('</head>',`<meta name="description" content="${E(d)}"><link rel="canonical" href="${BASE}/p/${p.slug}"><script type="application/ld+json">${JSON.stringify(ld).replace(/</g,'\\u003c')}</script></head>`))}));
app.use(express.static(pub,{index:false,maxAge:'1h'}));
app.get(/^\/(?!api\/|go\/).*/,(q,res)=>res.send(tpl()));
app.use((e,q,res,n)=>{console.error(e);fail(res,e.status||500,e.type==='entity.parse.failed'?'Invalid JSON':'Something went wrong')});
if(require.main===module)app.listen(PORT,()=>console.log('Pawprint on '+BASE));
module.exports=app;
